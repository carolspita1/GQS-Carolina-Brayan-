/// <reference types="cypress" />

describe('Testando tela de login', ()=>{

    beforeEach(()=> {
        cy.visit('http://localhost/cadastro/index2.php')
    })

    //teste1
    it('testes de usuario e senha errados', ()=>{
        cy.get('[type="text"]').type("seila")
        cy.get('[type="password"]').type("123")
        cy.get('.inputSubmit').click()
        cy.get('[type="text"]').should("have.text", "")
        cy.get('[type="password"]').should("have.text", "")
    })

    //teste2
    it('testes de usuario certo e senha errada', ()=>{
        cy.get('[type="text"]').type("usuario123")
        cy.get('[type="password"]').type("123")
        cy.get('.inputSubmit').click()
        cy.get('[type="text"]').should("have.text", "")
        cy.get('[type="password"]').should("have.text", "")
    })

    //teste3
    it('testes de caixas de texto vazias', ()=>{
        cy.get('.inputSubmit').click()
        cy.get('[type="text"]').should("have.text", "")
        cy.get('[type="password"]').should("have.text", "")
    })

    //teste4
    it('testes de usuario vazio e senha errada', ()=>{
        cy.get('[type="password"]').type("12345678")
        cy.get('.inputSubmit').click()
        cy.get('[type="text"]').should("have.text", "")
        cy.get('[type="password"]').should("have.text", "")
    })

    //teste5
    it('testes de usuario vazio e senha certa', ()=>{
        cy.get('[type="password"]').type("12345678")
        cy.get('.inputSubmit').click()
        cy.get('[type="text"]').should("have.text", "")
        cy.get('[type="password"]').should("have.text", "")
    })

    //teste6
    it('testes de usuario certo e senha vazia', ()=>{
        cy.get('[type="text"]').type("usuario123")
        cy.get('.inputSubmit').click()
        cy.get('[type="text"]').should("have.text", "")
        cy.get('[type="password"]').should("have.text", "")
    })

    //teste7
    it('testes de usuario errado e senha vazia', ()=>{
        cy.get('[type="text"]').type("usuario")
        cy.get('.inputSubmit').click()
        cy.get('[type="text"]').should("have.text", "")
        cy.get('[type="password"]').should("have.text", "")
    })

    //teste8
    it('testes de usuario certo e senha certa', ()=>{
        cy.visit('http://localhost/cadastro/index2.php')
        cy.get('[type="text"]').type("usuario123")
        cy.get('[type="text"]').type("12345678")
        cy.get('.inputSubmit').click()
        cy.visit('http://localhost/cadastro/indexCadastro.php')
    })

})

describe("Testando tela de cadastro", ()=>{
    
    describe("Tesntando com caixas de texto vazias", ()=>{

    beforeEach(()=> {
        cy.visit('http://localhost/cadastro/indexCadastro.php')
    })

    //teste9
    it('testando com caixas de texto vazias', ()=>{
        cy.get('#submit').click()
       
    })

    //teste10
    it('testando com 1 caixa de texto preenchida e as outras vazias', ()=>{
        cy.get('#nome').type('Brayan Lucas')
        cy.get('#submit').click()
        
    })

    //teste11
    it('testando com 2 caixa de texto preenchida e as outras vazias', ()=>{
        cy.get('#nome').type('Brayan Lucas')
        cy.get('#email').type('brayanlucas@gmail.com')
        cy.get('#submit').click()
        
    })

    //teste12
    it('testando com 3 caixa de texto preenchida e as outras vazias', ()=>{
        cy.get('#nome').type('Brayan Lucas')
        cy.get('#email').type('brayanlucas@gmail.com')
        cy.get('#endereco').type('Avenida do buraco')
        cy.get('#submit').click()
        
    })

    //teste13
    it('testando com 4 caixa de texto preenchida e data de nascimento vazia', ()=>{
        cy.get('#nome').type('Brayan Lucas')
        cy.get('#email').type('brayanlucas@gmail.com')
        cy.get('#endereco').type('Avenida do buraco')
        cy.get('#data_nascimento').type('2009-12-12')
        cy.get('#submit').click()
        
    })

    //teste14
    it('testando com 5 caixa de texto preenchida e data de nascimento vazia', ()=>{
        cy.get('#nome').type('Brayan Lucas')
        cy.get('#email').type('brayanlucas@gmail.com')
        cy.get('#endereco').type('Avenida do buraco')
        cy.get('#data_nascimento').type('2009-12-12')
        cy.get('#cidade').type('Rio Largo')
        cy.get('#submit').click()
    })

    //teste15
    it('testando com 6 caixa de texto preenchida e data de nascimento vazia', ()=>{
        cy.get('#nome').type('Brayan Lucas')
        cy.get('#email').type('brayanlucas@gmail.com')
        cy.get('#endereco').type('Avenida do buraco')
        cy.get('#data_nascimento').type('2009-12-12')
        cy.get('#cidade').type('Rio Largo')
        cy.get('#estado').type('AL')
        cy.get('#submit').click()
    })

    //teste16
    it('testando com todas as caixas preenchidas', ()=>{
        cy.get('#nome').type('Brayan Lucas')
        cy.get('#email').type('brayanlucas@gmail.com')
        cy.get('#endereco').type('Avenida do buraco')
        cy.get('#data_nascimento').type('2009-12-12')
        cy.get('#cidade').type('Rio Largo')
        cy.get('#estado').type('AL')
        cy.get('#bairro').type('Vila Rica')
        cy.get('#submit').click()
    })
    //teste17
    it(' testando botão voltar', ()=>{
        cy.visit('http://localhost/cadastro/indexCadastro.php')
        cy.get('.container-login100-form-btn > :nth-child(1)').click()
        cy.visit('http://localhost/cadastro/index2.php')
    })
    //teste18
    it(' testando botão Usuarios cadastrados', ()=>{
        cy.visit('http://localhost/cadastro/indexCadastro.php')
        cy.get('.container-login100-form-btn > :nth-child(3)').click()
        cy.visit('http://localhost/cadastro/usuariosCadastrados.php')
    })

  })

})

describe("Testando tela de Usuarios Cadastrados", ()=>{
    
    describe("Testando se os nomes estao certos", ()=>{

    beforeEach(()=> {
        cy.visit('http://localhost/cadastro/usuariosCadastrados.php')
    })
    //teste19
    it('testando o #', ()=>{
        cy.get('thead > tr > :nth-child(1)').should('have.text','#')
    })
    //teste20
    it('testando nome',()=>{
        cy.get('thead > tr > :nth-child(2)').should('have.text','Nome')
    })
    //teste21
    it('testando nome',()=>{
        cy.get('thead > tr > :nth-child(3)').should('have.text','Email')
    })
    //teste22
    it('testando nome',()=>{
        cy.get('thead > tr > :nth-child(4)').should('have.text','Endereço')
    })
    //teste23
    it('testando nome',()=>{
        cy.get('thead > tr > :nth-child(5)').should('have.text','Data de Nascimento')
    })
    //teste24
    it('testando nome',()=>{
        cy.get('thead > tr > :nth-child(6)').should('have.text','Cidade')
    })
    //teste25
    it('testando nome',()=>{
        cy.get('thead > tr > :nth-child(7)').should('have.text','Estado')
    })
    //teste26
    it('testando nome',()=>{
        cy.get('thead > tr > :nth-child(8)').should('have.text','Bairro')
    })

    })

    describe('Testando informações de usuarios', ()=>{
        beforeEach(()=> {
            cy.visit('http://localhost/cadastro/usuariosCadastrados.php')
        })
        //teste27
        it('testando se as informações da primeira linha esta correta', ()=>{
            cy.get('tbody > :nth-child(1) > :nth-child(1)').should('have.text','29')
            cy.get('tbody > :nth-child(1) > :nth-child(2)').should('have.text','Brayan Lucas')
            cy.get('tbody > :nth-child(1) > :nth-child(3)').should('have.text','brayanlucas@gmail.com')
            cy.get('tbody > :nth-child(1) > :nth-child(4)').should('have.text','Avenida do buraco')
            cy.get('tbody > :nth-child(1) > :nth-child(5)').should('have.text','2009-12-12')
            cy.get('tbody > :nth-child(1) > :nth-child(6)').should('have.text','Rio Largo')
            cy.get('tbody > :nth-child(1) > :nth-child(7)').should('have.text','AL')
            cy.get('tbody > :nth-child(1) > :nth-child(8)').should('have.text','Vila Rica')
        })
        //teste28
        it('testando se as informações da segunda linha esta correta', ()=>{
            cy.get('tbody > :nth-child(2) > :nth-child(1)').should('have.text','28')
            cy.get('tbody > :nth-child(2) > :nth-child(2)').should('have.text','Brayan Lucas')
            cy.get('tbody > :nth-child(2) > :nth-child(3)').should('have.text','brayanlucas@gmail.com')
            cy.get('tbody > :nth-child(2) > :nth-child(4)').should('have.text','Avenida do buraco')
            cy.get('tbody > :nth-child(2) > :nth-child(5)').should('have.text','2009-12-12')
            cy.get('tbody > :nth-child(2) > :nth-child(6)').should('have.text','Rio Largo')
            cy.get('tbody > :nth-child(2) > :nth-child(7)').should('have.text','AL')
            cy.get('tbody > :nth-child(2) > :nth-child(8)').should('have.text','Vila Rica')
        })
        //teste29
        it('testando se as informações da terceira linha esta correta', ()=>{
            cy.get('tbody > :nth-child(3) > :nth-child(1)').should('have.text','27')
            cy.get('tbody > :nth-child(3) > :nth-child(2)').should('have.text','Brayan Lucas')
            cy.get('tbody > :nth-child(3) > :nth-child(3)').should('have.text','brayanlucas@gmail.com')
            cy.get('tbody > :nth-child(3) > :nth-child(4)').should('have.text','Avenida do buraco')
            cy.get('tbody > :nth-child(3) > :nth-child(5)').should('have.text','2009-12-12')
            cy.get('tbody > :nth-child(3) > :nth-child(6)').should('have.text','Rio Largo')
            cy.get('tbody > :nth-child(3) > :nth-child(7)').should('have.text','AL')
            cy.get('tbody > :nth-child(3) > :nth-child(8)').should('have.text','Vila Rica')
        })
    })

    describe('testando os botões', ()=>{
        beforeEach(()=> {
            cy.visit('http://localhost/cadastro/usuariosCadastrados.php')
        })
        //teste30
        it('botão sair', ()=>{
            cy.visit('http://localhost/cadastro/usuariosCadastrados.php')
            cy.get('.d-flex > .btn').click()
        })
        //teste31
        it('botão excluir', ()=>{
            cy.visit('http://localhost/cadastro/usuariosCadastrados.php')
            cy.get(':nth-child(1) > :nth-child(9) > .btn-danger').click()
        })
        //teste32
        it('botão editar', ()=>{
            cy.visit('http://localhost/cadastro/usuariosCadastrados.php')
            cy.get(':nth-child(1) > :nth-child(9) > .btn-primary').click()
        })
     

     
 })

 describe('testando tela de edição', ()=>{
    beforeEach(()=> {
        cy.visit('http://localhost/cadastro/usuariosCadastrados.php')
    })
    //teste33
    it('testando input nome',()=>{
        cy.get(':nth-child(1) > :nth-child(9) > .btn-primary').click()
        cy.get('#nome').should('have.text','')
    })
    //teste34
    it('testando input email',()=>{
        cy.get(':nth-child(1) > :nth-child(9) > .btn-primary').click()
        cy.get('#email').should('have.text','')
    })
    //teste35
    it('testando input endereço',()=>{
        cy.get(':nth-child(1) > :nth-child(9) > .btn-primary').click()
        cy.get('#endereco').should('have.text','')
    })
    //teste36
    it('testando input data de nascimento',()=>{
        cy.get(':nth-child(1) > :nth-child(9) > .btn-primary').click()
        cy.get('#data_nascimento').should('have.text','')
    })
    //teste37
    it('testando input cidade',()=>{
        cy.get(':nth-child(1) > :nth-child(9) > .btn-primary').click()
        cy.get('#cidade').should('have.text','')
    })
    //teste38
    it('testando input estado',()=>{
        cy.get(':nth-child(1) > :nth-child(9) > .btn-primary').click()
        cy.get('#estado').should('have.text','')
    })
    //teste39
    it('testando input bairro',()=>{
        cy.get(':nth-child(1) > :nth-child(9) > .btn-primary').click()
        cy.get('#bairro').should('have.text','')
    })

    //teste40
    it('testando botão voltar',()=>{
        cy.get(':nth-child(1) > a').click()
    })

    //teste41
    it('testando botão de usuarios cadastrados', ()=>{
        cy.visit('http://localhost/cadastro/edit.php')
        cy.get('.container-login100-form-btn > :nth-child(3)').click()
    })

 })

})
   

   

    

